function showPage(id){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  window.scrollTo(0,0);
}

let fishes = JSON.parse(localStorage.getItem('fishhub_riverside')||'[]');
if(fishes.length==0){
  fishes=[
    {name:"Catfish",price:4500,phone:"08123456789",location:"Uta Ewa River",img:"https://images.unsplash.com/photo-1544551763-46a013bb70d5",time:Date.now()-120000},
    {name:"Tilapia",price:3000,phone:"08100001111",location:"Ikot Abasi",img:"https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2",time:Date.now()-600000}
  ];
}

function timeAgo(t){
  let m=Math.floor((Date.now()-t)/60000);
  if(m<1) return "Just now 🔴 LIVE";
  if(m<60) return m+" mins ago";
  return Math.floor(m/60)+" hrs ago";
}

function render(){
  let grid=document.getElementById('fishGrid');
  grid.innerHTML="";
  fishes.slice().reverse().forEach((f,i)=>{
    let real=fishes.length-1-i;
    grid.innerHTML+=`
      <div class="product">
        <small style="color:#00FF88">${timeAgo(f.time)}</small>
        <img src="${f.img}">
        <p><b style="color:white">${f.name}</b><br>₦${f.price}<br><small>${f.location}</small><br>
        <button class="buy-btn" style="width:100%" onclick="goPay(${real})">BUY NOW</button></p>
      </div>`;
    if((i+1)%3==0) grid.innerHTML+=`<div class="ad-box">ADVERT SPACE - You earn here</div>`;
  });
  localStorage.setItem('fishhub_riverside',JSON.stringify(fishes));
}

function createAccount(){
  let role=document.getElementById('role').value;
  let name=document.getElementById('uName').value;
  let phone=document.getElementById('uPhone').value;
  if(!name||!phone){alert("Fill name & phone");return;}
  localStorage.setItem('desiUser',JSON.stringify({role,name,phone}));
  document.getElementById('accMsg').innerText=`Account created as ${role}. Now you can ${role=='seller'?'post fish':'buy fish'}.`;
}

let currentBuy=null;
function goPay(i){
  currentBuy=fishes[i];
  document.getElementById('payInfo').innerHTML=`Fish: <b>${currentBuy.name}</b><br>Price: ₦${currentBuy.price}<br>Location: ${currentBuy.location}<br><br>Desi 10%: ₦${currentBuy.price*0.1}<br>Fisherman 90%: ₦${currentBuy.price*0.9}`;
  showPage('payment');
}

function payNow(){
  if(!currentBuy) return;
  let handler=PaystackPop.setup({
    key:'pk_test_xxxxxxxxxxxxxxxx',
    email:'buyer@desistores.com',
    amount:currentBuy.price*100,
    currency:'NGN',
    callback:function(res){
      window.open(`https://wa.me/${currentBuy.phone}?text=FISHUB SALE ${currentBuy.name} ₦${currentBuy.price} Ref ${res.reference}`,'_blank');
      alert("Payment Success! Fisherman contacted.");
      showPage('market');
    },
    onClose:()=>alert("Cancelled")
  });
  handler.openIframe();
}

let base64="";
document.getElementById('openSell').onclick=()=>{
  document.getElementById('sellModal').style.display='flex';
  document.getElementById('liveTime').innerText="Time: "+new Date().toLocaleString()+" • Auto-set";
};
document.getElementById('closeModal').onclick=()=>document.getElementById('sellModal').style.display='none';
document.getElementById('fImage').onchange=e=>{
  let file=e.target.files[0];if(!file) return;
  document.getElementById('fName').value=file.name.split('.')[0].replace(/[_-]/g," ");
  let r=new FileReader();
  r.onload=ev=>{base64=ev.target.result;let p=document.getElementById('preview');p.src=base64;p.style.display='block';};
  r.readAsDataURL(file);
};
document.getElementById('postFish').onclick=()=>{
  let n=document.getElementById('fName').value||"Fresh Fish";
  let p=document.getElementById('fPrice').value;
  let ph=document.getElementById('fPhone').value;
  let lo=document.getElementById('fLocation').value;
  if(!p||!ph||!base64){alert("Add Price, Phone & Fish Photo");return;}
  fishes.push({name:n,price:p,phone:ph,location:lo,img:base64,time:Date.now()});
  document.getElementById('sellModal').style.display='none';
  base64="";document.getElementById('preview').style.display='none';
  render();showPage('market');
};

render();